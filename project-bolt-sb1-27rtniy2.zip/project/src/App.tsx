import React from 'react';
import { Truck, Shield, Headphones, CreditCard, PawPrint as Paw, Star, Instagram, Facebook, Apple as WhatsApp } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Paw className="h-8 w-8 text-purple-600" />
            <span className="text-2xl font-bold text-purple-600">PetStore</span>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-600 hover:text-purple-600">Início</a>
            <a href="#products" className="text-gray-600 hover:text-purple-600">Produtos</a>
            <a href="#about" className="text-gray-600 hover:text-purple-600">Sobre Nós</a>
            <a href="#contact" className="text-gray-600 hover:text-purple-600">Contato</a>
          </nav>
          <button className="bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition">
            Compre Agora
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-b from-purple-50 to-white">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              Tudo que seu pet precisa em um só lugar!
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Produtos de qualidade para o bem-estar do seu animal de estimação.
            </p>
            <button className="bg-purple-600 text-white px-8 py-3 rounded-full text-lg hover:bg-purple-700 transition">
              Confira Nossos Produtos
            </button>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1450778869180-41d0601e046e?auto=format&fit=crop&w=800&q=80" 
              alt="Happy Dog"
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Por que escolher nossa loja?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: <Truck className="h-8 w-8" />, title: 'Frete Grátis' },
              { icon: <Shield className="h-8 w-8" />, title: 'Produtos 100% Seguros' },
              { icon: <Headphones className="h-8 w-8" />, title: 'Atendimento Personalizado' },
              { icon: <CreditCard className="h-8 w-8" />, title: 'Pagamento Facilitado' }
            ].map((benefit, index) => (
              <div key={index} className="flex flex-col items-center text-center p-6 rounded-lg hover:bg-purple-50 transition">
                <div className="text-purple-600 mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-semibold text-gray-800">{benefit.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section id="products" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Nossos Produtos Mais Vendidos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Ração Premium',
                price: 'R$ 89,90',
                image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?auto=format&fit=crop&w=500&q=80'
              },
              {
                name: 'Brinquedo Interativo',
                price: 'R$ 49,90',
                image: 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=500&q=80'
              },
              {
                name: 'Cama Luxo',
                price: 'R$ 129,90',
                image: 'https://images.unsplash.com/photo-1541599540903-216a46ca1dc0?auto=format&fit=crop&w=500&q=80'
              }
            ].map((product, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
                  <p className="text-purple-600 font-bold text-lg mb-4">{product.price}</p>
                  <button className="w-full bg-purple-600 text-white py-2 rounded hover:bg-purple-700 transition">
                    Comprar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
            O que nossos clientes dizem?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Ana Silva',
                text: 'Produtos de excelente qualidade! Meu cachorro adorou a ração premium.'
              },
              {
                name: 'Carlos Santos',
                text: 'Atendimento excepcional e entrega super rápida. Recomendo!'
              },
              {
                name: 'Maria Oliveira',
                text: 'Os brinquedos são muito resistentes e meu pet adora todos.'
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-purple-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">{testimonial.text}</p>
                <p className="font-semibold text-gray-800">{testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-purple-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Não perca tempo, seu pet merece o melhor!
          </h2>
          <p className="text-xl mb-8">
            Aproveite nossas promoções e compre agora.
          </p>
          <button className="bg-white text-purple-600 px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-100 transition">
            Ver Produtos
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Paw className="h-6 w-6 text-purple-400" />
                <span className="text-xl font-bold text-white">PetStore</span>
              </div>
              <p className="text-sm">
                Cuidando do seu pet com amor e dedicação.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Links Úteis</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-purple-400">Política de Privacidade</a></li>
                <li><a href="#" className="hover:text-purple-400">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-purple-400">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Contato</h3>
              <ul className="space-y-2">
                <li>contato@petstore.com</li>
                <li>(11) 99999-9999</li>
                <li>São Paulo, SP</li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Redes Sociais</h3>
              <div className="flex space-x-4">
                <a href="#" className="hover:text-purple-400">
                  <Instagram className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-purple-400">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-purple-400">
                  <WhatsApp className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p>&copy; 2024 PetStore. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Float Button */}
      <a
        href="https://wa.me/5511999999999"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 text-white p-3 rounded-full shadow-lg hover:bg-green-600 transition z-50"
      >
        <WhatsApp className="h-6 w-6" />
      </a>
    </div>
  );
}

export default App;